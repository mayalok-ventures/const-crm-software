const express = require('express');
const router = express.Router();
const multer = require('multer');
const {
  getLeads, getLead, createLead, updateLead,
  addNote, deleteLead, getTodayFollowUps, getDueFollowUps, getTags, trackMessage, trackCall,
  reassignLead, exportLeads, importLeads, toggleLeadOrgSharing,
  addChildInquiry, updateChildInquiry, deleteChildInquiry,
  scheduleFollowUp, delayFollowUp, completeFollowUp,
} = require('../controllers/leadsController');
const { protect, checkPlanExpiry } = require('../middleware/auth');
const { enforceExportGating } = require('../middleware/antiFraud');

// Multer in-memory storage for Excel/CSV parsing
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 15 * 1024 * 1024 }, // 15MB file size limit
});

router.use(protect);

// Export & Import Routes
router.get('/export', enforceExportGating, exportLeads);
router.post('/import', checkPlanExpiry, upload.single('file'), importLeads);

// Follow-Up & Alarm Endpoints
router.get('/follow-ups/today', getTodayFollowUps);
router.get('/follow-ups/due', getDueFollowUps);
router.post('/:id/follow-up', checkPlanExpiry, scheduleFollowUp);
router.post('/:id/follow-up/delay', checkPlanExpiry, delayFollowUp);
router.post('/:id/follow-up/complete', checkPlanExpiry, completeFollowUp);
// Aliases for backward compatibility
router.post('/:id/followups', checkPlanExpiry, scheduleFollowUp);
router.post('/:id/followups/delay', checkPlanExpiry, delayFollowUp);
router.post('/:id/followups/complete', checkPlanExpiry, completeFollowUp);
router.get('/tags', getTags);
router.post('/:id/track-message', checkPlanExpiry, trackMessage);
router.post('/:id/track-call', checkPlanExpiry, trackCall);
router.put('/:id/reassign', checkPlanExpiry, reassignLead);
router.put('/:id/share-organization', checkPlanExpiry, toggleLeadOrgSharing);

// K-12 Parent-Child Multi-Inquiry Sub-routes
router.post('/:id/children', checkPlanExpiry, addChildInquiry);
router.put('/:id/children/:childId', checkPlanExpiry, updateChildInquiry);
router.delete('/:id/children/:childId', checkPlanExpiry, deleteChildInquiry);

router.route('/').get(getLeads).post(checkPlanExpiry, createLead);
router.route('/:id').get(getLead).put(checkPlanExpiry, updateLead).delete(deleteLead);
router.post('/:id/notes', checkPlanExpiry, addNote);

module.exports = router;

