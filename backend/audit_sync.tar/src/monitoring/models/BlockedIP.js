"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.BlockedIP = void 0;
const mongoose_1 = __importStar(require("mongoose"));
const BlockedIPSchema = new mongoose_1.Schema({
    ip: {
        type: String,
        required: true,
        unique: true,
        index: true,
    },
    reason: {
        type: String,
        required: true,
    },
    blockedBy: {
        type: String,
        required: true,
        enum: ['SYSTEM_AUTO', 'ADMIN'],
        default: 'SYSTEM_AUTO',
    },
    adminUserId: {
        type: mongoose_1.Schema.Types.Mixed,
        default: null,
    },
    adminEmail: {
        type: String,
        default: null,
    },
    expiresAt: {
        type: Date,
        default: null,
        index: { expires: 0 }, // TTL index that removes document when expiresAt timestamp arrives
    },
    isActive: {
        type: Boolean,
        default: true,
        index: true,
    },
    hitCount: {
        type: Number,
        default: 0,
    },
    lastAttemptAt: {
        type: Date,
        default: Date.now,
    },
}, {
    timestamps: true,
});
exports.BlockedIP = mongoose_1.default.models.BlockedIP ||
    mongoose_1.default.model('BlockedIP', BlockedIPSchema);
