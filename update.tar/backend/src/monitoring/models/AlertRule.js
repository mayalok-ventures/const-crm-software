"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.AlertRule = void 0;
const mongoose_1 = __importStar(require("mongoose"));
const AlertRuleSchema = new mongoose_1.Schema({
    ruleId: { type: String, required: true, unique: true, index: true },
    name: { type: String, required: true },
    description: { type: String, default: '' },
    metric: {
        type: String,
        required: true,
        index: true,
    },
    operator: {
        type: String,
        required: true,
        enum: ['>', '<', '>=', '<=', '==', 'rate_increase', 'percentage_increase', 'absence_data'],
    },
    threshold: { type: mongoose_1.Schema.Types.Mixed, required: true },
    durationSeconds: { type: Number, default: 0 },
    severity: {
        type: String,
        required: true,
        enum: ['CRITICAL', 'WARNING', 'INFO'],
        default: 'WARNING',
        index: true,
    },
    cooldownMinutes: { type: Number, default: 15 },
    channels: [{ type: String }],
    targetResource: {
        type: { type: String, default: 'ALL' },
        identifier: { type: String, default: '*' },
    },
    isActive: { type: Boolean, default: true, index: true },
    silenceUntil: { type: Date, default: null },
    metadata: { type: mongoose_1.Schema.Types.Mixed, default: {} },
}, { timestamps: true });
exports.AlertRule = mongoose_1.default.models.AlertRule || mongoose_1.default.model('AlertRule', AlertRuleSchema);
exports.default = exports.AlertRule;
