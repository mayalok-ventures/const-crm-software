"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationDelivery = void 0;
const mongoose_1 = __importStar(require("mongoose"));
const NotificationDeliverySchema = new mongoose_1.Schema({
    deliveryId: { type: String, required: true, unique: true, index: true },
    alertId: { type: String, index: true },
    incidentId: { type: String, index: true },
    channelId: { type: String, required: true, index: true },
    channelName: { type: String, default: '' },
    channelType: { type: String, required: true },
    eventType: { type: String, required: true, index: true },
    status: {
        type: String,
        required: true,
        enum: ['PENDING', 'DELIVERED', 'FAILED', 'RATE_LIMITED', 'SKIPPED'],
        default: 'PENDING',
        index: true,
    },
    payload: { type: mongoose_1.Schema.Types.Mixed, default: {} },
    responseCode: { type: Number },
    responseBody: { type: String },
    latencyMs: { type: Number, default: 0 },
    attempts: { type: Number, default: 1 },
    error: { type: String, default: '' },
    deliveredAt: { type: Date, default: null },
}, { timestamps: true });
NotificationDeliverySchema.index({ createdAt: -1 });
exports.NotificationDelivery = mongoose_1.default.models.NotificationDelivery ||
    mongoose_1.default.model('NotificationDelivery', NotificationDeliverySchema);
exports.default = exports.NotificationDelivery;
