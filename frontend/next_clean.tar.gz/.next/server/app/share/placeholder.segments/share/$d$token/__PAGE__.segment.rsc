1:"$Sreact.fragment"
2:I[1992,["766","static/chunks/766-6096508501495eec.js","796","static/chunks/app/share/%5Btoken%5D/page-bc6d7d4c10c608d3.js"],"default"]
3:I[90484,[],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{}],null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"QIu50iYrnpDz85IBe-eXN"}
5:null
