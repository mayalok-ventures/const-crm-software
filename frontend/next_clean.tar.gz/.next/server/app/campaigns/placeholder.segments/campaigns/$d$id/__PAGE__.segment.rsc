1:"$Sreact.fragment"
2:I[17254,["766","static/chunks/766-6096508501495eec.js","530","static/chunks/530-411f61ca7a8155dc.js","529","static/chunks/529-94784358c91fcfb6.js","930","static/chunks/930-02b8f13df5fd9b27.js","516","static/chunks/app/campaigns/%5Bid%5D/page-ab8d29d0add03d78.js"],"default"]
3:I[90484,[],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{}],null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"QIu50iYrnpDz85IBe-eXN"}
5:null
