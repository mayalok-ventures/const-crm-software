1:"$Sreact.fragment"
2:I[6927,["766","static/chunks/766-6096508501495eec.js","530","static/chunks/530-411f61ca7a8155dc.js","198","static/chunks/198-3ad2466bee0db371.js","149","static/chunks/149-244e7939444bc22c.js","254","static/chunks/254-3fac0b8b73296d14.js","384","static/chunks/app/leads/%5Bid%5D/page-b305db581569eb72.js"],"default"]
3:I[90484,[],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{}],null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"QIu50iYrnpDz85IBe-eXN"}
5:null
