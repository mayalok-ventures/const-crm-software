(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[974],{50150:(e,n,t)=>{"use strict";t.r(n),t.d(n,{default:()=>o});var a=t(95155),l=t(12115);function o(){return(0,l.useEffect)(()=>{localStorage.getItem("token")?window.location.replace("/dashboard"):window.location.replace("/login")},[]),(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)("script",{dangerouslySetInnerHTML:{__html:`
            if (localStorage.getItem('token')) {
              window.location.replace('/dashboard');
            } else {
              window.location.replace('/login');
            }
          `}}),(0,a.jsx)("div",{style:{display:"flex",alignItems:"center",justifyContent:"center",minHeight:"100dvh",background:"var(--bg)"},children:(0,a.jsx)("div",{className:"spinner"})})]})}},57565:(e,n,t)=>{Promise.resolve().then(t.bind(t,50150))}},e=>{e.O(0,[441,794,358],()=>e(e.s=57565)),_N_E=e.O()}]);